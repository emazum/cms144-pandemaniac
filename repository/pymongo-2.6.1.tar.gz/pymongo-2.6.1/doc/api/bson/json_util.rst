:mod:`json_util` -- Tools for using Python's :mod:`json` module with BSON documents
======================================================================================
.. versionadded:: 1.1.1

.. automodule:: bson.json_util
   :synopsis: Tools for using Python's json module with BSON documents
   :members:
   :undoc-members:
